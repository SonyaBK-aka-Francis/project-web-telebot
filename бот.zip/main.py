from flask import Flask
from data import db_session
from data.users import User
# Импортируем необходимые классы.
import logging
import datetime
from telegram.ext import Application, MessageHandler, filters, ConversationHandler, CallbackQueryHandler
from telegram.ext import ApplicationBuilder
# Добавим необходимый объект из модуля telegram.ext
from telegram.ext import CommandHandler
from telegram import ReplyKeyboardMarkup
from telegram import ReplyKeyboardRemove
from telegram import InlineKeyboardMarkup, InlineKeyboardButton
from translatepy import Translator

translator = Translator()

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

# Запускаем логгирование
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.DEBUG
)

logger = logging.getLogger(__name__)

change_keyboard = [['/change_name', '/change_number'],
                   ['/change_floor', '/change_flat']]
markup = ReplyKeyboardMarkup(change_keyboard, one_time_keyboard=True)


async def eng(update, context):
    global trans
    trans = True
    await update.message.reply_text("Language changed to English.")


async def rus(update, context):
    global trans
    trans = False
    await update.message.reply_text("Язык изменён на русский.")


async def close_keyboard(update, context):
    await update.message.reply_text(
        "Ok", reply_markup=ReplyKeyboardRemove())


async def help(update, context):
    global trans
    if not trans:
        await update.message.reply_text(
            "Список доступных команд:\n "
            "/eng - change language to English\n"
            "/rus - изменить язык на русский\n"
            "/register - добавление в базу данных\n"
            "/delete - удалить информацию из базы данных\n"  # здесь будет меню с кнопками
            "/change - изменить информацию в базе данных\n"  # здесь будет меню с кнопками
            "/info - информация о другом пользователе\n"
            "/help - справочная информация\n"
            "/stop - остановить диалог\n")
    else:
        await update.message.reply_text(
            "Available commands:\n "
            "/eng - change language to English\n"
            "/rus - изменить язык на русский\n"
            "/register - add to database\n"
            "/delete - delete info from database\n"  # здесь будет меню с кнопками
            "/change - change info in database\n"  # здесь будет меню с кнопками
            "/info - info about another resident\n"
            "/help - info about bot\n"
            "/stop - stop dialog\n")


async def start(update, context):
    global trans
    if not trans:
        await update.message.reply_text(
            "Привет! Список доступных команд:\n "
            "/eng - change language to English\n"
            "/rus - изменить язык на русский\n"
            "/register - добавление в базу данных\n"
            "/delete - удалить информацию из базы данных\n"  # здесь будет меню с кнопками
            "/change - изменить информацию в базе данных\n"  # здесь будет меню с кнопками
            "/info - информация о другом пользователе\n"
            "/help - справочная информация\n"
            "/stop - остановить диалог\n")
    else:
        await update.message.reply_text(
            "Hello! Available commands:\n "
            "/eng - change language to English\n"
            "/rus - изменить язык на русский\n"
            "/register - add to database\n"
            "/delete - delete info from database\n"  # здесь будет меню с кнопками
            "/change - change info in database\n"  # здесь будет меню с кнопками
            "/info - info about another resident\n"
            "/help - info about bot\n"
            "/stop - stop dialog\n")


async def info(update, context):
    global trans
    a = []
    keyboard = []
    db_session.global_init("db/residents.db")
    db_sess = db_session.create_session()
    for user in db_sess.query(User).all():
        a.append(user.floor)
    floors = list(set(a))
    for i in range(len(floors)):
        urlButton = [InlineKeyboardButton(str(floors[i]), callback_data=f'{str(floors[i])}')]
        keyboard.append(urlButton)
    reply_markup = InlineKeyboardMarkup(keyboard)
    if len(db_session.create_session().query(User).filter
               (User.username == update.message.from_user.username).all()) > 0:
        if not trans:
            await update.message.reply_text("Выберите этаж:", reply_markup=reply_markup)
        else:
            await update.message.reply_text("Choose the floor:", reply_markup=reply_markup)
    else:
        if not trans:
            await update.message.reply_text("Сначала зарегистрируйтесь в базе данных с помощью команды /register.")
        else:
            await update.message.reply_text(str(translator.translate(
                "Сначала зарегистрируйтесь в базе данных с помощью команды /register.", "English")))


async def button(update, context):
    global trans
    c = []
    b = []
    k = []
    db_session.global_init("db/residents.db")
    db_sess = db_session.create_session()
    query = update.callback_query
    if 'кв' in query.data:
        await query.answer()
        for user in db_sess.query(User).filter(User.flat == int(query.data[:-2])).all():
            c.append([user.name, user.username, user.number])
        if not trans:
            await query.edit_message_text('Жильцы:')
        else:
            await query.edit_message_text('Residents:')
        for el in c:
            if not trans:
                await query.message.reply_text(f"Как обращаться: {el[0]}\n"
                                               f"Ник в телеграмме: @{el[1]}\n"
                                               f"Номер телефона: {el[2]}\n"
                                               f"\n")
            else:
                await query.message.reply_text(f"Name: {el[0]}\n"
                                               f"Username: @{el[1]}\n"
                                               f"Phone number: {el[2]}\n"
                                               f"\n")
    else:
        await query.answer()
        for user in db_sess.query(User).filter(User.floor == int(query.data)).all():
            b.append(user.flat)
        flats = list(set(b))
        for i in range(len(flats)):
            url = [InlineKeyboardButton(str(flats[i]), callback_data=f'{str(flats[i])}кв')]
            k.append(url)
        rep = InlineKeyboardMarkup(k)
        if not trans:
            await query.edit_message_text("Выберите квартиру:", reply_markup=rep)
        else:
            await query.edit_message_text("Choose the flat:", reply_markup=rep)


async def change(update, context):
    global trans
    db_session.global_init("db/residents.db")
    if len(db_session.create_session().query(User).filter
               (User.username == update.message.from_user.username).all()) > 0:
        if not trans:
            await update.message.reply_text("Выберите параметр для изменения:", reply_markup=markup)
        else:
            await update.message.reply_text(str(translator.translate(
                "Выберите параметр для изменения:", "English")), reply_markup=markup)
    else:
        if not trans:
            await update.message.reply_text("Сначала зарегистрируйтесь в базе данных с помощью команды /register.")
        else:
            await update.message.reply_text(str(translator.translate(
                "Сначала зарегистрируйтесь в базе данных с помощью команды /register.", "English")))


async def delete(update, context):
    global trans
    db_session.global_init("db/residents.db")
    db_sess = db_session.create_session()
    if len(db_session.create_session().query(User).filter
               (User.username == update.message.from_user.username).all()) > 0:
        user = db_sess.query(User).filter(User.username == update.message.from_user.username).first()
        db_sess.delete(user)
        db_sess.commit()
        if not trans:
            await update.message.reply_text("Удаление успешно!")
        else:
            await update.message.reply_text(str(translator.translate("Удаление успешно!", "English")))
    else:
        if not trans:
            await update.message.reply_text("Сначала зарегистрируйтесь в базе данных с помощью команды /register.")
        else:
            await update.message.reply_text(str(translator.translate(
                "Сначала зарегистрируйтесь в базе данных с помощью команды /register.", "English")))


async def change_name(update, context):
    global trans
    if not trans:
        await update.message.reply_text("Введите новое обращение", reply_markup=ReplyKeyboardRemove())
    else:
        await update.message.reply_text(
            str(translator.translate("Введите новое обращение", "English")), reply_markup=ReplyKeyboardRemove())
    return 1


async def change_name_two(update, context):
    global trans
    db_session.global_init("db/residents.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter(User.username == update.message.from_user.username).first()
    user.name = update.message.text
    db_sess.commit()
    if not trans:
        await update.message.reply_text("Изменение успешно!")
    else:
        await update.message.reply_text(str(translator.translate("Изменение успешно!", "English")))
    return ConversationHandler.END


async def change_number(update, context):
    global trans
    if not trans:
        await update.message.reply_text("Введите новый номер", reply_markup=ReplyKeyboardRemove())
    else:
        await update.message.reply_text(
            str(translator.translate("Введите новый номер", "English")), reply_markup=ReplyKeyboardRemove())
    return 1


async def change_number_two(update, context):
    global trans
    db_session.global_init("db/residents.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter(User.username == update.message.from_user.username).first()
    user.number = int(update.message.text)
    db_sess.commit()
    if not trans:
        await update.message.reply_text("Изменение успешно!")
    else:
        await update.message.reply_text(str(translator.translate("Изменение успешно!", "English")))
    return ConversationHandler.END


async def change_floor(update, context):
    global trans
    if not trans:
        await update.message.reply_text("Введите новый этаж", reply_markup=ReplyKeyboardRemove())
    else:
        await update.message.reply_text(
            str(translator.translate("Введите новый этаж", "English")), reply_markup=ReplyKeyboardRemove())
    return 1


async def change_floor_two(update, context):
    global trans
    db_session.global_init("db/residents.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter(User.username == update.message.from_user.username).first()
    user.floor = int(update.message.text)
    db_sess.commit()
    if not trans:
        await update.message.reply_text("Изменение успешно!")
    else:
        await update.message.reply_text(str(translator.translate("Изменение успешно!", "English")))
    return ConversationHandler.END


async def change_flat(update, context):
    global trans
    if not trans:
        await update.message.reply_text("Введите новую квартиру", reply_markup=ReplyKeyboardRemove())
    else:
        await update.message.reply_text(
            str(translator.translate("Введите новую квартиру", "English")), reply_markup=ReplyKeyboardRemove())
    return 1


async def change_flat_two(update, context):
    global trans
    db_session.global_init("db/residents.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter(User.username == update.message.from_user.username).first()
    user.flat = int(update.message.text)
    db_sess.commit()
    if not trans:
        await update.message.reply_text("Изменение успешно!")
    else:
        await update.message.reply_text(str(translator.translate("Изменение успешно!", "English")))
    return ConversationHandler.END


async def register(update, context):
    global trans
    db_session.global_init("db/residents.db")
    global un
    un = update.message.from_user.username
    if len(db_session.create_session().query(User).filter(User.username == un).all()) > 0:
        if not trans:
            await update.message.reply_text("Пользователь уже зарегистрирован.")
        else:
            await update.message.reply_text(str(translator.translate("Пользователь уже зарегистрирован.", "English")))
        return ConversationHandler.END
    else:
        if not trans:
            await update.message.reply_text(
                "Привет. Для регистрации пройдите небольшой опрос, пожалуйста!\n"
                "Ваш номер телефона? ")
        else:
            await update.message.reply_text(str(translator.translate("Привет. Для регистрации пройдите небольшой "
                                                                     "опрос, пожалуйста!\nВаш номер телефона? ",
                                                                     "English")))
        return 1


async def first_response(update, context):
    global trans
    db_session.global_init("db/residents.db")
    global num
    # Это ответ на первый вопрос.
    # Мы можем использовать его во втором вопросе.
    num = int(update.message.text)
    if len(db_session.create_session().query(User).filter(User.number == num).all()) > 0:
        if not trans:
            await update.message.reply_text("Номер уже существует.")
        else:
            await update.message.reply_text(str(translator.translate("Номер уже существует.", "English")))
        return 1
    else:
        if not trans:
            await update.message.reply_text("Как к Вам обращаться?")
        else:
            await update.message.reply_text(str(translator.translate("Как к Вам обращаться?", "English")))
        return 2


async def second_response(update, context):
    global trans
    global nick
    # Это ответ на первый вопрос.
    # Мы можем использовать его во втором вопросе.
    nick = update.message.text
    if not trans:
        await update.message.reply_text("Какой у Вас этаж?")
    else:
        await update.message.reply_text(str(translator.translate("Какой у Вас этаж?", "English")))
    # Следующее текстовое сообщение будет обработано
    # обработчиком states[2]
    return 3


async def third_response(update, context):
    global trans
    global floor
    # Это ответ на первый вопрос.
    # Мы можем использовать его во втором вопросе.
    floor = int(update.message.text)
    if not trans:
        await update.message.reply_text("Какая у Вас квартира?")
    else:
        await update.message.reply_text(str(translator.translate("Какая у Вас квартира?", "English")))
    # Следующее текстовое сообщение будет обработано
    # обработчиком states[2]
    return 4


async def fourth_response(update, context):
    global trans
    global flat
    flat = int(update.message.text)
    db_session.global_init("db/residents.db")

    user = User()
    user.name = nick
    user.username = un
    user.number = num
    user.floor = floor
    user.flat = flat
    db_sess = db_session.create_session()
    db_sess.add(user)
    db_sess.commit()
    if not trans:
        await update.message.reply_text("Спасибо за регистрацию! Список доступных команд:\n "
                                        "/eng - change language to English\n"
                                        "/rus - изменить язык на русский\n"
                                        "/delete - удалить информацию из базы данных\n"  # здесь будет меню с кнопками
                                        "/change - изменить информацию в базе данных\n"  # здесь будет меню с кнопками
                                        "/info - информация о другом пользователе\n"
                                        "/help - справочная информация\n"
                                        "/stop - остановить диалог\n")
    else:
        await update.message.reply_text("Thanks for the registration! Available commands:\n "
                                        "/eng - change language to English\n"
                                        "/rus - изменить язык на русский\n"
                                        "/delete - delete info from database\n"  # здесь будет меню с кнопками
                                        "/change - change info in database\n"  # здесь будет меню с кнопками
                                        "/info - info about another resident\n"
                                        "/help - info about bot\n"
                                        "/stop - stop dialog\n")
    return ConversationHandler.END  # Константа, означающая конец диалога.
    # Все обработчики из states и fallbacks становятся неактивными.


async def stop(update, context):
    global trans
    if not trans:
        await update.message.reply_text("Всего доброго!")
    else:
        await update.message.reply_text(str(translator.translate("Всего доброго!", "English")))
    return ConversationHandler.END


def main():
    global trans
    trans = False
    # Создаём объект Application.
    # Вместо слова "TOKEN" надо разместить полученный от @BotFather токен
    application = Application.builder().token('7199907908:AAERYRL9LK9fAhdK81WP1E-saY0Jjg43Zyk').build()

    # Создаём обработчик сообщений типа filters.TEXT
    # из описанной выше асинхронной функции echo()
    # После регистрации обработчика в приложении
    # эта асинхронная функция будет вызываться при получении сообщения
    # с типом "текст", т. е. текстовых сообщений.
    conv_handler = ConversationHandler(
        # Точка входа в диалог.
        # В данном случае — команда /start. Она задаёт первый вопрос.
        entry_points=[CommandHandler('register', register)],

        # Состояние внутри диалога.
        # Вариант с двумя обработчиками, фильтрующими текстовые сообщения.
        states={
            # Функция читает ответ на первый вопрос и задаёт второй.
            1: [MessageHandler(filters.TEXT & ~filters.COMMAND, first_response)],
            # Функция читает ответ на второй вопрос и завершает диалог.
            2: [MessageHandler(filters.TEXT & ~filters.COMMAND, second_response)],
            3: [MessageHandler(filters.TEXT & ~filters.COMMAND, third_response)],
            4: [MessageHandler(filters.TEXT & ~filters.COMMAND, fourth_response)]
        },

        # Точка прерывания диалога. В данном случае — команда /stop.
        fallbacks=[CommandHandler('stop', stop)]
    )

    change_handler_name = ConversationHandler(
        # Точка входа в диалог.
        # В данном случае — команда /change_name. Она задаёт первый вопрос.
        entry_points=[CommandHandler('change_name', change_name)],

        # Состояние внутри диалога.
        # Вариант с двумя обработчиками, фильтрующими текстовые сообщения.
        states={
            # Функция читает ответ на первый вопрос и задаёт второй.
            1: [MessageHandler(filters.TEXT & ~filters.COMMAND, change_name_two)]
        },

        # Точка прерывания диалога. В данном случае — команда /stop.
        fallbacks=[CommandHandler('stop', stop)]
    )

    change_handler_number = ConversationHandler(
        # Точка входа в диалог.
        # В данном случае — команда /change_name. Она задаёт первый вопрос.
        entry_points=[CommandHandler('change_number', change_number)],

        # Состояние внутри диалога.
        # Вариант с двумя обработчиками, фильтрующими текстовые сообщения.
        states={
            # Функция читает ответ на первый вопрос и задаёт второй.
            1: [MessageHandler(filters.TEXT & ~filters.COMMAND, change_number_two)]
        },

        # Точка прерывания диалога. В данном случае — команда /stop.
        fallbacks=[CommandHandler('stop', stop)]
    )

    change_handler_floor = ConversationHandler(
        # Точка входа в диалог.
        # В данном случае — команда /change_name. Она задаёт первый вопрос.
        entry_points=[CommandHandler('change_floor', change_floor)],

        # Состояние внутри диалога.
        # Вариант с двумя обработчиками, фильтрующими текстовые сообщения.
        states={
            # Функция читает ответ на первый вопрос и задаёт второй.
            1: [MessageHandler(filters.TEXT & ~filters.COMMAND, change_floor_two)]
        },

        # Точка прерывания диалога. В данном случае — команда /stop.
        fallbacks=[CommandHandler('stop', stop)]
    )

    change_handler_flat = ConversationHandler(
        # Точка входа в диалог.
        # В данном случае — команда /change_name. Она задаёт первый вопрос.
        entry_points=[CommandHandler('change_flat', change_flat)],

        # Состояние внутри диалога.
        # Вариант с двумя обработчиками, фильтрующими текстовые сообщения.
        states={
            # Функция читает ответ на первый вопрос и задаёт второй.
            1: [MessageHandler(filters.TEXT & ~filters.COMMAND, change_flat_two)]
        },

        # Точка прерывания диалога. В данном случае — команда /stop.
        fallbacks=[CommandHandler('stop', stop)]
    )
    # Регистрируем обработчик в приложении.
    application.add_handler(change_handler_name)
    application.add_handler(change_handler_number)
    application.add_handler(change_handler_floor)
    application.add_handler(change_handler_flat)
    application.add_handler(conv_handler)

    # Зарегистрируем их в приложении перед
    # регистрацией обработчика текстовых сообщений.
    # Первым параметром конструктора CommandHandler
    # является название команды.
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help))
    application.add_handler(CommandHandler("register", register))
    application.add_handler(CommandHandler("change_name", change_name))
    application.add_handler(CommandHandler("change_number", change_number))
    application.add_handler(CommandHandler("change_floor", change_floor))
    application.add_handler(CommandHandler("change_flat", change_flat))
    application.add_handler(CommandHandler("change", change))
    application.add_handler(CommandHandler("delete", delete))
    application.add_handler(CommandHandler("close", close_keyboard))
    application.add_handler(CommandHandler("info", info))
    application.add_handler(CommandHandler("button", button))
    application.add_handler(CommandHandler("stop", stop))
    application.add_handler(CommandHandler("eng", eng))
    application.add_handler(CommandHandler("rus", rus))
    application.add_handler(CallbackQueryHandler(button))

    # Запускаем приложение.
    application.run_polling()


if __name__ == '__main__':
    main()
